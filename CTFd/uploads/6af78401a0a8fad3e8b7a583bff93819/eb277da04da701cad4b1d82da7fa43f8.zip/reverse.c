#include <stdio.h>
int main(int argc, char** argv)
{
    unsigned char flag[] = "9e99117fac74043a6768d94fea3817ef142c3fa22e5de77a34491bbab47343b2"
    printf("Flag is %s\n", flag);
    return 0;
}
